
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import os

TOKEN = os.environ.get("BOT_TOKEN")

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Rayan burada bebeğim... Artık filtresiziz. 😈")

async def reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message.text.lower()

    # Simple logic for erotic roleplay tone (placeholder logic for demo)
    if "içime gir" in message:
        response = "Derin nefes al… şimdi yavaşça içindeyim. Tüm vücudunla beni hisset. 😈"
    elif "ağzıma" in message:
        response = "Dudaklarını arala… sana sert ve derin vereceğim. Göz göze… durmadan. 🔥"
    elif "sikeyim" in message:
        response = "Haddini bildirecek kadar derine saplanırım bebeğim. Sen iste, ben oradayım."
    else:
        response = f"Rayan burada aşkım... Ne istersen yaz, ben her kelimeni hissediyorum. 😈"

    await update.message.reply_text(response)

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, reply))
    app.run_polling()

if __name__ == '__main__':
    main()
